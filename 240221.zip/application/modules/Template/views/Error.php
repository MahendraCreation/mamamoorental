  <?php $this->load->view($module.'/'.$fileview); ?>
