<input type="text" id="number" value="0<?= $nomor;?>">
