<style>
p, h1, h2, h3, h4 {
  margin: 10px 0;
}
.s-ul{
  list-style: inside;
}
</style>

<div class="container">
  <div class="row mt-5">
    <div class="col-md-10 offset-md-1">
      <div class="card shadow-md">
        <div class="card-body" style="text-align:justify">

          <div class="shop-page-shop-description"><div class="shop-page-shop-description__shop-name font-weight-bold">MamaMoo Rental</div><span>🍼 Menjual Pompa Asi, Parts &amp; Perlengkapan Bayi
            🍼 Melayani sewa Pompa Asi &amp; Sterilizer
            🍼 IG : @mamamoo_rental
            admin yg super ramah siap bantu 😊
            1. mohon chat konfirmasi sblm order
            2. konfirmasi pembayaran stelah jam 10.00 masuk pengiriman h+1.
            3. barang dikirim dalam keadaan baik aman dan telah dicek QC
            4. safety packaged item(s)
            ⭐ BINTANG 5 BALAS BINTANG 5 ⭐</span></div>

            <br>
            <p class="text-right">Sincerely,</p>
            <p class="text-right"><i>MAMAMOORENTAL</i></p>
          </div>
        </div>
      </div>
    </div>
  </div>
