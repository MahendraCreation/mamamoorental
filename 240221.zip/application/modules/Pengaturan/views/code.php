<input type="text" name="code" class="form-control" value="<?= $code;?>" readonly>
