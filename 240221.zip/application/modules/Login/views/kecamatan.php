  <?php foreach ($get_kec as $kec) { ?>
    <option value="<?php echo $kec->kode;?>"><?php echo $kec->nama;?></option>
  <?php }?>
