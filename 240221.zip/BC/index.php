<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml"><head>
<!--[if gte mso 9]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<!--[if !mso]><!-->
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<!--<![endif]-->
<title>Halo Sob!</title>
<!--[if !mso]><!-->
<!--<![endif]-->
<style type="text/css">body{margin:0;padding:0}table,td,tr{vertical-align:top;border-collapse:collapse}*{line-height:inherit}a[x-apple-data-detectors="true"]{color:inherit!important;text-decoration:none!important}.ie-browser table{table-layout:fixed}[owa] .img-container div,[owa] .img-container button{display:block!important}[owa] .fullwidth button{width:100%!important}[owa] .block-grid .col{display:table-cell;float:none!important;vertical-align:top}.ie-browser .block-grid,.ie-browser .num12,[owa] .num12,[owa] .block-grid{width:900px!important}.ie-browser .mixed-two-up .num4,[owa] .mixed-two-up .num4{width:300px!important}.ie-browser .mixed-two-up .num8,[owa] .mixed-two-up .num8{width:600px!important}.ie-browser .block-grid.two-up .col,[owa] .block-grid.two-up .col{width:450px!important}.ie-browser .block-grid.three-up .col,[owa] .block-grid.three-up .col{width:450px!important}.ie-browser .block-grid.four-up .col [owa] .block-grid.four-up .col{width:225px!important}.ie-browser .block-grid.five-up .col [owa] .block-grid.five-up .col{width:180px!important}.ie-browser .block-grid.six-up .col,[owa] .block-grid.six-up .col{width:150px!important}.ie-browser .block-grid.seven-up .col,[owa] .block-grid.seven-up .col{width:128px!important}.ie-browser .block-grid.eight-up .col,[owa] .block-grid.eight-up .col{width:112px!important}.ie-browser .block-grid.nine-up .col,[owa] .block-grid.nine-up .col{width:100px!important}.ie-browser .block-grid.ten-up .col,[owa] .block-grid.ten-up .col{width:60px!important}.ie-browser .block-grid.eleven-up .col,[owa] .block-grid.eleven-up .col{width:54px!important}.ie-browser .block-grid.twelve-up .col,[owa] .block-grid.twelve-up .col{width:50px!important}</style>
<style id="media-query" type="text/css">@media only screen and (min-width:920px){.block-grid{width:900px!important}.block-grid .col{vertical-align:top}.block-grid .col.num12{width:900px!important}.block-grid.mixed-two-up .col.num3{width:225px!important}.block-grid.mixed-two-up .col.num4{width:300px!important}.block-grid.mixed-two-up .col.num8{width:600px!important}.block-grid.mixed-two-up .col.num9{width:675px!important}.block-grid.two-up .col{width:450px!important}.block-grid.three-up .col{width:300px!important}.block-grid.four-up .col{width:225px!important}.block-grid.five-up .col{width:180px!important}.block-grid.six-up .col{width:150px!important}.block-grid.seven-up .col{width:128px!important}.block-grid.eight-up .col{width:112px!important}.block-grid.nine-up .col{width:100px!important}.block-grid.ten-up .col{width:90px!important}.block-grid.eleven-up .col{width:81px!important}.block-grid.twelve-up .col{width:75px!important}}@media (max-width:920px){.block-grid,.col{min-width:320px!important;max-width:100%!important;display:block!important}.block-grid{width:100%!important}.col{width:100%!important}.col>div{margin:0 auto}img.fullwidth,img.fullwidthOnMobile{max-width:100%!important}.no-stack .col{min-width:0!important;display:table-cell!important}.no-stack.two-up .col{width:50%!important}.no-stack .col.num4{width:33%!important}.no-stack .col.num8{width:66%!important}.no-stack .col.num4{width:33%!important}.no-stack .col.num3{width:25%!important}.no-stack .col.num6{width:50%!important}.no-stack .col.num9{width:75%!important}.video-block{max-width:none!important}.mobile_hide{min-height:0;max-height:0;max-width:0;display:none;overflow:hidden;font-size:0}.desktop_hide{display:block!important;max-height:none!important}}</style>
</head>
<body class="clean-body" style="margin: 0; padding: 0; -webkit-text-size-adjust: 100%; background-color: #FFFFFF;">
<style id="media-query-bodytag" type="text/css">@media (max-width:920px){.block-grid{min-width:320px!important;max-width:100%!important;width:100%!important;display:block!important}.col{min-width:320px!important;max-width:100%!important;width:100%!important;display:block!important}.col>div{margin:0 auto}img.fullwidth{max-width:100%!important;height:auto!important}img.fullwidthOnMobile{max-width:100%!important;height:auto!important}.no-stack .col{min-width:0!important;display:table-cell!important}.no-stack.two-up .col{width:50%!important}.no-stack.mixed-two-up .col.num4{width:33%!important}.no-stack.mixed-two-up .col.num8{width:66%!important}.no-stack.three-up .col.num4{width:33%!important}.no-stack.four-up .col.num3{width:25%!important}}</style>
<!--[if IE]><div class="ie-browser"><![endif]-->
<table bgcolor="#FFFFFF" cellpadding="0" cellspacing="0" class="nl-container" role="presentation" style="table-layout:fixed;vertical-align:top;min-width:320px;margin:0 auto;border-spacing:0;background-image:url(https://www.jagoanhosting.com/wp-content/uploads/2019/05/Tampilan-Pelanggan-3.jpg);background-size:cover;background-repeat:no-repeat;background-position:center center;border-collapse:collapse;mso-table-lspace:0;mso-table-rspace:0;background-color:#fff;width:100%" valign="top" width="100%">
<tbody>
<tr style="vertical-align: top;height: 100%;" valign="top">
<td style="word-break: break-word;vertical-align: top;border-collapse: collapse;height: 100%;" valign="top">
<!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" style="background-color:#FFFFFF"><![endif]-->


<div style="background-position:top left;background-repeat:no-repeat;background-color:transparent;background-size:100%;padding-top:50px;padding-left:10px;padding-bottom:80px">
<div class="block-grid" style="margin-left: 50px;min-width: 320px;/* max-width: 900px; */overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: transparent;">
<div style="border-collapse: collapse;display: table;width: 100%;">
<div class="col num6" style="min-width: 320px; max-width: 450px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 50px;font-family: 'Roboto Slab', serif;margin: 0;"><span style="font-size: 42px;"><strong><link href="https://fonts.googleapis.com/css?family=Roboto+Slab&amp;display=swap" rel="stylesheet">
<span style="line-height: 50px; font-size: 42px;">Halo, Sobat Jagoan!</span></strong></span></p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px;line-height: 14px;color: #555555;font-family: 'Roboto Slab', serif;">
<p style="font-size: 18px; line-height: 16px; margin: 0;">Selamat kamu sudah menjadi bagian dari <b>#AutoKeren</b> Jagoan Hosting Indonesia</p><br>

</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>

</div><div class="block-grid three-up" style="Margin: 0 auto; min-width: 320px; max-width: 900px; overflow-wrap: break-word; word-wrap: break-word; word-break: break-word; background-color: transparent;;">
<div style="border-collapse: collapse;display: table;width: 100%;background-color:transparent;">
<!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:transparent;"><tr><td align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:900px"><tr class="layout-full-width" style="background-color:transparent"><![endif]-->
<!--[if (mso)|(IE)]><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2019/02/Promo_Hosting-114.png" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;border: 0;height: 97px;float: none;width: auto;/* max-width: 101px; */display: block;" title="Image" width="90">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top: 0px;padding-right: 0px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">Login cPanel</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Login akun cpanel kamu di member area</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2019/05/Aset-Email-Bisnis-10-150x150.png" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;border: 0;height: auto;float: none;width: 100%;max-width: 92px;display: block;" title="Image" width="96">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel/membuat-akun-email-cpanel?utm_campaign=DefaultPageTracking_BuatAkunEmail&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">Buat Akun Email</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Pengen punya email pake nama domain sendiri? Ini caranya!</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2018/11/Icon_Benefit-27.png" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;border: 0;height: auto;float: none;width: 100%;max-width: 92px;display: block;" title="Image" width="101">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/tutorial-aktivasi-ssl?utm_campaign=DefaultPageTracking_InstallSSL&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">Install SSL</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Ikuti cara mudah install SSL disini</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
</div>
</div><div class="block-grid three-up" style="Margin: 0 auto; min-width: 320px; max-width: 900px; overflow-wrap: break-word; word-wrap: break-word; word-break: break-word; background-color: transparent;;">
<div style="border-collapse: collapse;display: table;width: 100%;background-color:transparent;">
<!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:transparent;"><tr><td align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:900px"><tr class="layout-full-width" style="background-color:transparent"><![endif]-->
<!--[if (mso)|(IE)]><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2019/03/Aset-Hosting-Mini-new-22.png" style="outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; clear: both; border: 0; height: auto; float: none; width: 100%; max-width: 101px; display: block;" title="Image" width="101">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-hosting/install-aplikasi-cms-dari-softaculous?utm_campaign=DefaultPageTracking_InstallWebsite&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">Install Website</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Selanjutnya kamu bisa melakukan instalasi aplikasi website</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2019/02/Aset_Gopay-55.png" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;border: 0;height: 101px;float: none;width: 100%;max-width: 96px;display: block;" title="Image" width="96">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-domain/addon-domain?utm_campaign=DefaultPageTracking_AddonDomain&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">Menambahkan Domain</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Kamu bisa simpan lebih dari 1 website dalam 1 hosting dengan Addon Domain</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td><td align="center" width="300" style="background-color:transparent;width:300px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num4" style="max-width: 320px; min-width: 300px; display: table-cell; vertical-align: top;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]--><img align="center" alt="Image" border="0" class="center autowidth" src="https://www.jagoanhosting.com/wp-content/uploads/2019/05/Vector-Smart-Object-copy.png" style="outline: none;text-decoration: none;-ms-interpolation-mode: bicubic;clear: both;border: 0;height: 101px;float: none;width: 100%;max-width: 96px;display: block;" title="Image" width="96">
<!--[if mso]></td></tr></table><![endif]-->
</div>
<div align="center" class="button-container" style="padding-top:5px;padding-right:5px;padding-bottom:5px;padding-left:5px;">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-spacing: 0; border-collapse: collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;"><tr><td style="padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px" align="center"><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="" style="height:31.5pt; width:111.75pt; v-text-anchor:middle;" arcsize="62%" stroke="false" fillcolor="#53156F"><w:anchorlock/><v:textbox inset="0,0,0,0"><center style="color:#ffffff; font-family:Arial, sans-serif; font-size:16px"><![endif]-->
<div style="text-decoration:none;display:inline-block;color:#ffffff;background-color:#53156F;border-radius:26px;-webkit-border-radius:26px;-moz-border-radius:26px;width:auto; width:auto;;border-top:1px solid #53156F;border-right:1px solid #53156F;border-bottom:1px solid #53156F;border-left:1px solid #53156F;padding-top:5px;padding-bottom:5px;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;text-align:center;mso-border-alt:none;word-break:keep-all;"><span style="padding-left:20px;padding-right:20px;font-size:16px;display:inline-block;color: white;"><a href="https://www.jagoanhosting.com/tutorial/tutorial-cpanel-2/login-ke-cpanel?utm_campaign=DefaultPageTracking_LogincPanel&amp;utm_medium=halamandefault&amp;utm_source=WHMCS"></a>
<span style="font-size: 16px; line-height: 32px;"><a href="https://www.jagoanhosting.com/tutorial/andro-virtual-assistant-jagoan-hosting?utm_campaign=DefaultPageTracking_PDKTsamaAndro&amp;utm_medium=halamandefault&amp;utm_source=WHMCS" style="
    color: white;
    text-decoration: none;
    font-family: 'Roboto Slab', serif;
">PDKT sama Andro</a></span>
</span></div>
<!--[if mso]></center></v:textbox></v:roundrect></td></tr></table><![endif]-->
</div>
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 10px; padding-left: 10px; padding-top: 10px; padding-bottom: 10px; font-family: Arial, sans-serif"><![endif]-->
<div style="color:#555555;font-family:Arial, 'Helvetica Neue', Helvetica, sans-serif;line-height:120%;padding-top:10px;padding-right:10px;padding-bottom:10px;padding-left:10px;">
<div style="font-size: 12px; line-height: 14px; color: #555555; font-family: Arial, 'Helvetica Neue', Helvetica, sans-serif;">
<p style="font-size: 14px;line-height: 16px;text-align: center;font-family: 'Roboto Slab', serif;margin: 0;">Yuk kenalan sama virtual assistance Jagoan Hosting yang online 24 jam ini</p>
</div>
</div>
<!--[if mso]></td></tr></table><![endif]-->
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
</div>
</div>

<div style="border-collapse: collapse;display: table;width: 100%;background-color:transparent;">
<!--[if (mso)|(IE)]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:transparent;"><tr><td align="center"><table cellpadding="0" cellspacing="0" border="0" style="width:900px"><tr class="layout-full-width" style="background-color:transparent"><![endif]-->
<!--[if (mso)|(IE)]><td align="center" width="675" style="background-color:transparent;width:675px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num9" style="display: table-cell; vertical-align: top; min-width: 320px; max-width: 675px;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div align="center" class="img-container center autowidth fullwidth">
<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr style="line-height:0px"><td style="" align="center"><![endif]-->
<!--[if mso]></td></tr></table><![endif]-->
</div>
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td><td align="center" width="225" style="background-color:transparent;width:225px; border-top: 0px solid transparent; border-left: 0px solid transparent; border-bottom: 0px solid transparent; border-right: 0px solid transparent;" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding-right: 0px; padding-left: 0px; padding-top:5px; padding-bottom:5px;"><![endif]-->
<div class="col num3" style="display: table-cell; vertical-align: top; max-width: 320px; min-width: 225px;;">
<div style="width:100% !important;">
<!--[if (!mso)&(!IE)]><!-->
<div style="border-top:0px solid transparent; border-left:0px solid transparent; border-bottom:0px solid transparent; border-right:0px solid transparent; padding-top:5px; padding-bottom:5px; padding-right: 0px; padding-left: 0px;">
<!--<![endif]-->
<div></div>
<!--[if (!mso)&(!IE)]><!-->
</div>
<!--<![endif]-->
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
<!--[if (mso)|(IE)]></td></tr></table></td></tr></table><![endif]-->
</div>
</div>
</div>
<!--[if (mso)|(IE)]></td></tr></table><![endif]-->
</td>
</tr>
</tbody>
</table>
<!--[if (IE)]></div><![endif]-->

</body></html>